import java.io.*;
import java.net.*;

public class Acceptor {
    private static final String HOSTNAME = "localhost";
    private static final int PORT = 12345;

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Acceptor <ClientName>");
            return;
        }

        String clientName = args[0];

        try (Socket socket = new Socket(HOSTNAME, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println(clientName + " connected as Acceptor");

            int lastPromisedId = 0;
            while (true) {
                System.out.println(lastPromisedId + "________________");
                String message = in.readLine();
                if (message != null && message.startsWith("PREPARE")) {
                    String[] parts = message.split(" ");
                    int proposalId = Integer.parseInt(parts[1]);

                    System.out.println(clientName + " received PREPARE with ID " + proposalId);

                    if (proposalId > lastPromisedId) {
                        lastPromisedId = proposalId;
                        out.println("PROMISE " + proposalId + " " + clientName);
                    }
                } else if (message != null && message.startsWith("PROPOSE")) {
                    String[] parts = message.split(" ");
                    int proposalId = Integer.parseInt(parts[1]);

                    if (proposalId == lastPromisedId) {
                        System.out.println(clientName + " accepted PROPOSE with ID " + proposalId);
                        out.println("ACCEPTED " + proposalId + " " + clientName);
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("Error in Acceptor " + clientName + ": " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
