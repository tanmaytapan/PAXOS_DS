import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java Client <ClientName> [ClientNumber] [ValueToPropose]");
            return;
        }

        String hostname = "localhost";
        int port = 12345;
        String clientName = args[0];
        String clientNumber = args.length > 1 ? args[1] : "";
        String valueToPropose = args.length > 2 ? args[2] : "";

        try (Socket socket = new Socket(hostname, port)) {
            System.out.println("Client '" + clientName + "' connected to the server.");

            OutputStream output = socket.getOutputStream();
            InputStream input = socket.getInputStream();

            String messageToSend = clientName;
            if (!clientNumber.isEmpty() && !valueToPropose.isEmpty()) {
                messageToSend += ", " + clientNumber + ", " + valueToPropose;
            }
            output.write(messageToSend.getBytes());

            byte[] buffer = new byte[1024];
            int bytesRead = input.read(buffer);
            String receivedMessage = new String(buffer, 0, bytesRead);
            System.out.println("Server says: " + receivedMessage);
        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O error: " + ex.getMessage());
        }
    }
}
