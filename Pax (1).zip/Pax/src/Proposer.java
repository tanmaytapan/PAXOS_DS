import java.io.*;
import java.net.*;
import java.util.*;

public class Proposer {
    private static final String HOSTNAME = "localhost";
    private static final int PORT = 12345;
    private static final int MAJORITY = 5; // Majority including itself
    private static final long RETRY_DELAY_MS = 2000; // 2 seconds

    public static void main(String[] args) {
        if (args.length != 4) {
            System.out.println("Usage: java Proposer <ClientName> <ValueToPropose> <ClientNumber>");
            return;
        }

        String clientName = args[0];
        Integer nodeNumber = Integer.parseInt(args[1]);
        String valueToPropose = args[2];
        Integer delayArg = Integer.parseInt(args[3]);

        try (Socket socket = new Socket(HOSTNAME, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println(clientName + " connected as Proposer");

            int proposalId = 1; // Starting proposal ID

            while (true) {
                int Uid = 3 * proposalId + nodeNumber;

                out.println("PREPARE " + Uid + " " + clientName);
                System.out.println(clientName + " sent PREPARE with ID " + Uid);

                Thread.sleep(delayArg);

                Set<String> promises = new HashSet<>();
                promises.add(clientName); // Proposer promises to itself

                long startTime = System.currentTimeMillis();
                while (System.currentTimeMillis() - startTime < RETRY_DELAY_MS) {
                    if (in.ready()) {
                        String response = in.readLine();
                        if (response != null && response.startsWith("PROMISE")) {
                            promises.add(response);
                        }
                    }
                }



                if (promises.size() >= MAJORITY) {
                    // Send PROPOSE message
                    out.println("PROPOSE " + Uid + " " + valueToPropose + " " + clientName);
                    System.out.println(clientName + " sent PROPOSE with ID " + Uid + " and value " + valueToPropose);

                    Thread.sleep(delayArg);

                    // Wait for ACCEPT responses
                    Set<String> accepts = new HashSet<>();
                    accepts.add(clientName);
                    startTime = System.currentTimeMillis();
                    while (System.currentTimeMillis() - startTime < RETRY_DELAY_MS) {
                        if (in.ready()) {
                            String response = in.readLine();
                            if (response != null && response.startsWith("ACCEPTED")) {
                                accepts.add(response);
                                if (accepts.size() >= MAJORITY) {
                                    System.out.println("Consensus reached on proposal ID " + Uid + " with value '" + valueToPropose + "'");
                                    return; // Exit after consensus is reached
                                }
                            }
                        }
                    }
                }

                // Retry with incremented proposal ID
                System.out.println("Majority not achieved, retrying with incremented proposal ID...");
                Thread.sleep(RETRY_DELAY_MS);
                proposalId++;
            }
        } catch (IOException | InterruptedException ex) {
            System.out.println("Error in Proposer " + clientName + ": " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}